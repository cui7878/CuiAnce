CREATE TABLE records (
 owner TEXT NOT NULL,
 kind TEXT NOT NULL,
 id TEXT NOT NULL,
 payload TEXT NOT NULL,
 version INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL,
 PRIMARY KEY (owner, kind, id)
);
CREATE INDEX records_owner_updated ON records(owner, updated_at DESC);
