import {build} from 'esbuild';import fs from 'node:fs/promises';
const output=await build({entryPoints:['src/app.js'],bundle:true,minify:true,format:'iife',write:false,target:'es2022',legalComments:'inline'});
let html=await fs.readFile('src/index.html','utf8');const css=(await fs.readFile('src/style.css','utf8')).replace(/^@import\s+url\([^)]*\)\s*;\s*/m,'');
const script=output.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
html=html.replace('<link rel="stylesheet" href="/style.css">',()=>'<style>'+css+'</style>').replace('<script type="module" src="/app.js"></script>',()=>'<script>'+script+'</script>').replace('支持多设备制单、云端保存与 A4 打印。','无需登录，本地保存，支持 A4 单据与 100×150 mm 面单打印。');
await fs.mkdir('site',{recursive:true});await fs.writeFile('site/index.html',html);await fs.writeFile('site/.nojekyll','');
console.log('Standalone local website built: site/index.html');
