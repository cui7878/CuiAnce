import {spawnSync} from 'node:child_process';
let buffer='';for await (const chunk of process.stdin){buffer+=chunk;if(buffer.includes('\n'))break;}
const {credential:c}=JSON.parse(buffer);
function run(args,auth=false){const env={...process.env};if(auth&&c.token){env.GIT_CONFIG_COUNT='1';env.GIT_CONFIG_KEY_0='http.extraHeader';env.GIT_CONFIG_VALUE_0='Authorization: Bearer '+c.token;}const r=spawnSync('git',args,{encoding:'utf8',env});if(r.status!==0){process.stderr.write((r.stderr||'Git failed').replaceAll(c.token||'NONSECRET','[redacted]'));process.exit(r.status||1);}return r.stdout.trim();}
if(!run(['rev-parse','--git-dir']).startsWith('.git'))process.exit(1);
const remote=spawnSync('git',['remote','get-url','origin'],{encoding:'utf8'});
run(['remote',remote.status===0?'set-url':'add','origin',c.remote_url]);
run(['push','-u','origin','HEAD:'+c.branch],true);
process.stdout.write(JSON.stringify({commit_sha:run(['rev-parse','HEAD'])}));
