import {sqliteTable,text,integer,primaryKey,index} from 'drizzle-orm/sqlite-core';
export const records=sqliteTable('records',{
 owner:text('owner').notNull(),kind:text('kind').notNull(),id:text('id').notNull(),payload:text('payload').notNull(),version:integer('version').notNull().default(1),updated_at:text('updated_at').notNull()
},table=>[primaryKey({columns:[table.owner,table.kind,table.id]}),index('records_owner_updated').on(table.owner,table.updated_at)]);
