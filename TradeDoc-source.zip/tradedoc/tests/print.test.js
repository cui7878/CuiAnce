import test from 'node:test';import assert from 'node:assert/strict';
let print={};try{print=await import('../src/print.js');}catch{}
const doc={type:'PI',number:'PI1',date:'2026-11-14',currency:'USD',seller:{name:'Seller'},buyer:{name:'<script>bad</script>'},items:[{name:'Cup',qty:2,price:10,unit:'PCS',net:3,gross:4,cartons:1}],notes:'<img onerror=x>'};
test('invoice preview escapes user fields and renders financial total',()=>{assert.equal(typeof print.documentPaper,'function');const html=print.documentPaper(doc);assert.ok(html.includes('Proforma Invoice'));assert.ok(html.includes('$20.00'));assert.ok(!html.includes('<script>'));assert.ok(html.includes('&lt;script&gt;'));});
test('packing list shows weights instead of financial columns',()=>{assert.equal(typeof print.documentPaper,'function');const html=print.documentPaper({...doc,type:'PL'});assert.ok(html.includes('Gross'));assert.ok(!html.includes('Unit price'));assert.ok(!html.includes('$20.00'));});
test('sales contract contains signing spaces',()=>{assert.equal(typeof print.documentPaper,'function');const html=print.documentPaper({...doc,type:'SC'});assert.ok(html.includes('Sales Contract'));assert.ok(html.includes('Buyer signature'));});
test('unit-price precision remains consistent with printed line totals',()=>{
 const html=print.documentPaper({...doc,items:[{name:'Cup',qty:100,price:.125,unit:'PCS'}]});
 assert.ok(html.includes('$0.125'));assert.ok(html.includes('$12.50'));
});
