import test from 'node:test';
import assert from 'node:assert/strict';
let domain = {};
try { domain = await import('../src/domain.js'); } catch {}
test('monetary totals round each line before summing', () => {
 assert.equal(typeof domain.totals, 'function');
 assert.equal(domain.totals([{qty:3,price:0.1},{qty:1,price:1.005}]).amount, 1.31);
});
test('invalid negative quantities and non-finite prices are rejected', () => {
 assert.equal(typeof domain.validateDocument, 'function');
 assert.throws(()=>domain.validateDocument({type:'PI',number:'PI1',buyer:{name:'Buyer'},items:[{name:'Cup',qty:-1,price:1}]}));
 assert.throws(()=>domain.validateDocument({type:'ZZ',items:[]}));
});
test('HTML and attribute values escape hostile text', () => {
 assert.equal(typeof domain.escapeHTML, 'function');
 assert.equal(domain.escapeHTML('<img onerror="x">'), '&lt;img onerror=&quot;x&quot;&gt;');
});
test('decimal half-cent ties round up without binary float errors',()=>{
 assert.equal(domain.totals([{qty:1,price:10.075}]).amount,10.08);
 assert.equal(domain.totals([{qty:3,price:0.335}]).amount,1.01);
});
test('negative quantity is rejected in an otherwise valid document',()=>{
 assert.throws(()=>domain.validateDocument({type:'PI',number:'PI1',date:'2026-11-14',currency:'USD',seller:{name:'Seller'},buyer:{name:'Buyer'},items:[{name:'Cup',qty:-1,price:5}]}),/数量/);
});
