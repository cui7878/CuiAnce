import test from 'node:test';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';import {readFileSync} from 'node:fs';
const settle=()=>new Promise(r=>setImmediate(r));
async function setup(type='PI'){
 const dom=new JSDOM(readFileSync(new URL('../src/index.html',import.meta.url),'utf8'),{url:'https://example.test',pretendToBeVisual:true});
 const w=dom.window;for(const key of ['window','document','location','FormData','Image'])globalThis[key]=key==='window'?w:w[key];
 w.scrollTo=()=>{};w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};
 globalThis.fetch=async()=>{throw Error('Local app must not request the network');};
 await import('../src/app.js?test='+crypto.randomUUID());await settle();
 const click=s=>{const el=w.document.querySelector(s);assert.ok(el,`missing ${s}`);el.click();};
 const fill=(name,value)=>{const el=w.document.querySelector(`[name="${name}"]`);assert.ok(el,name);el.value=value;el.dispatchEvent(new w.Event('input',{bubbles:true}));};
 click(`[data-action="new"][data-type="${type}"]`);fill('seller.name','Seller');fill('buyer.name','Buyer');if(type==='SL'){fill('seller.phone','13800138000');fill('seller.address','上海市示例路 1 号');fill('buyer.phone','13900139000');fill('buyer.address','北京市示例路 2 号');fill('shipping.carrier','通用快递');fill('shipping.tracking','123456789012');}else{fill('items.0.name','Cup');fill('items.0.price','10');}
 return {w,click,fill,get saved(){return JSON.parse(w.localStorage.getItem('tradedoc-local-v1')||'{"records":[]}').records.find(r=>r.kind==='documents');}};
}
test('leaving the editor offers a way to resume the same unsaved draft',async()=>{
 const ui=await setup();ui.fill('items.0.qty','7');ui.click('[data-action="nav"][data-page="docs"]');
 const resume=ui.w.document.querySelector('[data-action="resumedraft"]');assert.ok(resume,'A resume draft action must remain visible');resume.click();assert.equal(ui.w.document.querySelector('[name="items.0.qty"]').value,'7');ui.w.close();
});
test('edits entered during a local save remain in the active draft',async()=>{
 const ui=await setup();ui.click('[data-action="savedoc"]');ui.fill('items.0.qty','9');await settle();await settle();
 const field=ui.w.document.querySelector('[name="items.0.qty"]');assert.ok(field,'editor must remain open for the later edits');assert.equal(field.value,'9');assert.equal(ui.saved.value.items[0].qty,1);ui.w.close();
});
test('document editor identifies its place in the desktop breadcrumb',async()=>{
 const ui=await setup();assert.equal(ui.w.document.querySelector('.breadcrumb b').textContent,'单据编辑');ui.w.close();
});

test('shipping editor omits invoice fields and preserves 100x150 preview through local save',async()=>{
 const ui=await setup('SL');assert.equal(ui.w.document.querySelector('[name="currency"]'),null);assert.equal(ui.w.document.querySelector('[name="items.0.price"]'),null);
 ui.click('[data-action="previewdraft"]');assert.ok(ui.w.document.querySelector('.preview-modal .shipping-label'));assert.match(ui.w.document.querySelector('.modal-header').textContent,/100 × 150/);ui.click('[data-action="close"]');
 ui.click('[data-action="savedoc"]');await settle();assert.ok(ui.saved);assert.equal(ui.saved.value.type,'SL');assert.equal(ui.saved.value.shipping.tracking,'123456789012');await settle();await settle();
 const record=ui.w.document.querySelector('.record-row');assert.ok(record);assert.ok(!record.textContent.includes('$'));ui.click('[data-action="preview"]');assert.ok(ui.w.document.querySelector('.shipping-label'));ui.w.close();
});
test('printing shipping label then invoice selects separate page layouts',async()=>{
 const ui=await setup('SL');const printed=[];globalThis.requestAnimationFrame=cb=>cb();ui.w.print=()=>{printed.push(ui.w.document.querySelector('#print-root article').className);};
 ui.click('[data-action="previewdraft"]');ui.click('[data-action="print"]');await settle();await settle();assert.equal(printed[0],'shipping-label');ui.click('[data-action="close"]');
 ui.click('[data-action="nav"][data-page="home"]');ui.click('[data-action="sample"]');ui.click('[data-action="print"]');await settle();await settle();assert.equal(printed[1],'paper');ui.w.close();
});
test('copying a saved shipping label clears its tracking number and keeps the original',async()=>{
 const ui=await setup('SL');ui.click('[data-action="savedoc"]');await settle();await settle();await settle();ui.click('[data-action="copydoc"]');
 assert.equal(ui.w.document.querySelector('[name="shipping.tracking"]').value,'');assert.equal(ui.w.document.querySelector('[name="buyer.name"]').value,'Buyer');assert.equal(ui.saved.value.shipping.tracking,'123456789012');ui.w.close();
});
test('label printing refuses overflow rather than clipping recipient details',async()=>{
 const ui=await setup('SL');let prints=0;ui.w.print=()=>prints++;ui.click('[data-action="previewdraft"]');const label=ui.w.document.querySelector('.preview-modal .shipping-label');Object.defineProperty(label,'clientHeight',{value:560});Object.defineProperty(label,'scrollHeight',{value:630});ui.click('[data-action="print"]');await settle();
 assert.equal(prints,0);assert.match(ui.w.document.querySelector('#toast').textContent,/超出/);assert.ok(ui.w.document.querySelector('#modal').open);ui.w.close();
});

test('local settings offer backups and contain no sign-in or sign-out links',async()=>{
 const ui=await setup();assert.equal(ui.w.document.querySelector('.alert'),null);ui.click('[data-action="nav"][data-page="settings"]');assert.ok(ui.w.document.querySelector('[data-action="exportbackup"]'));assert.ok(ui.w.document.querySelector('#backup-file'));assert.equal(ui.w.document.querySelector('a[href*="signout"],a[href*="signin"]'),null);assert.match(ui.w.document.body.textContent,/本地/);ui.w.close();
});
