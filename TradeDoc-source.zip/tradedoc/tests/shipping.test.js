import test from 'node:test';import assert from 'node:assert/strict';
import {validateDocument} from '../src/domain.js';import {documentPaper} from '../src/print.js';
let shipping={};try{shipping=await import('../src/shipping.js');}catch{}
export const label={type:'SL',number:'SL-001',date:'2026-11-14',seller:{name:'寄件人',phone:'13800138000',address:'上海市浦东新区示例路 1 号'},buyer:{name:'收件人',phone:'13900139000',address:'北京市海淀区示例路 2 号'},shipping:{carrier:'通用快递',tracking:'123456789012',parcels:1,weight:1.5,contents:'样品'},items:[]};
test('shipping label validates without invoice currency or product lines',()=>assert.equal(validateDocument(structuredClone(label)).type,'SL'));
test('label rejects missing phone, address, tracking and excessive text',()=>{
 for(const [parent,key]of [['buyer','phone'],['buyer','address'],['seller','phone'],['shipping','tracking']]){const d=structuredClone(label);d[parent][key]='';assert.throws(()=>validateDocument(d));}
 const d=structuredClone(label);d.buyer.address='地址'.repeat(150);assert.throws(()=>validateDocument(d));
});
test('CODE128 produces compressed numeric symbols and includes quiet zones',()=>{
 assert.equal(typeof shipping.barcodeData,'function');const code=shipping.barcodeData('123456789012');
 assert.equal(code.bits.length,101);assert.ok(code.bits.startsWith('11010011100'));assert.ok(code.bits.endsWith('1100011101011'));assert.equal(code.quiet,10);
});
test('unsupported tracking characters and barcodes too dense for 100mm fail explicitly',()=>{
 assert.equal(typeof shipping.barcodeData,'function');assert.throws(()=>shipping.barcodeData('订单123'));
 assert.throws(()=>shipping.barcodeData('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890ABCD'));
});
test('shipping preview contains label-specific fields and escapes user content',()=>{
 const html=documentPaper({...label,buyer:{...label.buyer,name:'<script>alert(1)</script>'}});
 assert.ok(html.includes('shipping-label'));assert.ok(html.includes('100 × 150 mm'));assert.ok(html.includes('123456789012'));assert.ok(html.includes('<svg'));assert.ok(html.includes('&lt;script&gt;'));assert.ok(!html.includes('<script>'));assert.ok(!html.includes('BANK DETAILS'));assert.ok(!html.includes('TOTAL'));
});
