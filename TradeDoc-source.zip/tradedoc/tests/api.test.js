import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {api} from '../src/api.js';
function database(){const db=new DatabaseSync(':memory:');db.exec(readFileSync(new URL('../drizzle/0000_previous_union_jack.sql',import.meta.url),'utf8'));return {prepare(sql){return {bind(...args){return {async all(){return {results:db.prepare(sql).all(...args)};},async run(){return {meta:{changes:Number(db.prepare(sql).run(...args).changes)}};}};}};}};}
const req=(method,path,body,user='alice')=>new Request('https://example.test'+path,{method,headers:{...(user?{'oai-authenticated-user-id':user}:{}),'Content-Type':'application/json','Origin':'https://example.test'},body:body?JSON.stringify(body):undefined});
test('missing identity is rejected before storage access',async()=>assert.equal((await api(req('GET','/api/state',null,null),{})).status,401));
test('cloud records persist, isolate users, and reject stale writes/deletes',async()=>{
 const env={DB:database()};
 const r={kind:'customers',id:'a',version:0,value:{name:'Buyer A'}};
 assert.equal((await api(req('POST','/api/records',r),env)).status,200);
 assert.equal((await api(req('POST','/api/records',r),env)).status,409);
 const a=await(await api(req('GET','/api/state'),env)).json();
 assert.equal(a.records[0].value.name,'Buyer A');
 const b=await(await api(req('GET','/api/state',null,'bob'),env)).json();assert.equal(b.records.length,0);
 assert.equal((await api(req('DELETE','/api/records',{...r,version:1},'bob'),env)).status,409);
 assert.equal((await api(req('POST','/api/records',{...r,version:1,value:{name:'Updated'}}),env)).status,200);
 assert.equal((await api(req('DELETE','/api/records',{...r,version:1}),env)).status,409);
 assert.equal((await api(req('DELETE','/api/records',{...r,version:2}),env)).status,200);
 const empty=await(await api(req('GET','/api/state'),env)).json();assert.equal(empty.records.length,0);
});
test('cross-origin writes and malformed product prices are rejected',async()=>{
 const env={DB:database()};
 const r=req('POST','/api/records',{kind:'products',id:'p',value:{name:'Cup',price:-3,stock:0}});
 assert.equal((await api(r,env)).status,400);
 const other=req('POST','/api/records',{});other.headers.set('Origin','https://evil.test');assert.equal((await api(other,env)).status,403);
});
test('unsupported product currency is rejected before it can break the UI',async()=>{
 const response=await api(req('POST','/api/records',{kind:'products',id:'p',value:{name:'Cup',price:5,stock:0,currency:'INVALID'}}),{DB:database()});assert.equal(response.status,400);
});

test('100x150 shipping labels round-trip through the authenticated cloud records API',async()=>{
 const env={DB:database()},value={type:'SL',number:'SL1',date:'2026-11-14',seller:{name:'Sender',phone:'12345',address:'Shanghai'},buyer:{name:'Recipient',phone:'67890',address:'Beijing'},shipping:{carrier:'Generic',tracking:'123456789012',parcels:1,weight:2},items:[]};
 assert.equal((await api(req('POST','/api/records',{kind:'documents',id:'sl1',value}),env)).status,200);
 const state=await(await api(req('GET','/api/state'),env)).json();assert.equal(state.records[0].value.shipping.tracking,'123456789012');
 value.buyer.phone='';assert.equal((await api(req('POST','/api/records',{kind:'documents',id:'sl2',value}),env)).status,400);
});
