import test from 'node:test';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';import {readFileSync} from 'node:fs';import {JSDOM,VirtualConsole} from 'jsdom';
test('standalone local file boots without network resources or authentication',async()=>{
 const build=spawnSync(process.execPath,['scripts/build-local.mjs'],{cwd:new URL('..',import.meta.url),encoding:'utf8'});assert.equal(build.status,0,build.stderr);
 const html=readFileSync(new URL('../site/index.html',import.meta.url),'utf8');assert.ok(!/src="https?:|href="https?:|@import|src="\/app.js"/.test(html));
 const errors=[],virtualConsole=new VirtualConsole();virtualConsole.on('jsdomError',error=>errors.push(error.message));
 const dom=new JSDOM(html,{url:'https://example.test/CuiAnce/',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole,beforeParse(w){w.fetch=()=>{throw Error('No network allowed');};w.scrollTo=()=>{};w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};}});
 await new Promise(r=>setImmediate(r));assert.deepEqual(errors,[]);assert.ok(dom.window.document.querySelector('[data-action="new"][data-type="SL"]'));assert.equal(dom.window.document.querySelector('.alert'),null);assert.equal(dom.window.document.querySelector('a[href*="signin"]'),null);dom.window.close();
});
