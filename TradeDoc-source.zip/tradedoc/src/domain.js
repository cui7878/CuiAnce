import {validateShipping} from './shipping.js';
export const TYPES = {PI:{name:'PI / 报价单',en:'Proforma Invoice',color:'blue'},CI:{name:'商业发票',en:'Commercial Invoice',color:'green'},SC:{name:'销售合同',en:'Sales Contract',color:'orange'},PL:{name:'装箱单',en:'Packing List',color:'purple'},SL:{name:'快递面单',en:'Shipping Label',color:'teal'}};
export const escapeHTML = (value='') => String(value??'').replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
export const money = (n,currency='USD') => new Intl.NumberFormat('en-US',{style:'currency',currency,maximumFractionDigits:2}).format(n||0);
export function cents(n){return Math.round((Number(n)+Number.EPSILON)*100);}
function decimal(value){
 const n=Number(value||0);if(!Number.isFinite(n))return [0n,0];
 const [mantissa,exponent='0']=String(n).toLowerCase().split('e');
 const fraction=(mantissa.split('.')[1]||'').length;
 return [BigInt(mantissa.replace('.','')),fraction-Number(exponent)];
}
export function lineCents(qty,price){
 const [q,qs]=decimal(qty),[p,ps]=decimal(price),scale=qs+ps-2,product=q*p;
 if(scale<=0)return Number(product*10n**BigInt(-scale));
 const divisor=10n**BigInt(scale),negative=product<0n,absolute=negative?-product:product;
 const rounded=(absolute+divisor/2n)/divisor;
 return Number(negative?-rounded:rounded);
}
export const unitPrice=(n,currency='USD')=>new Intl.NumberFormat('en-US',{style:'currency',currency,minimumFractionDigits:2,maximumFractionDigits:20}).format(Number(n)||0);
export function totals(items=[]){let sum=0;const result=items.reduce((a,i)=>{sum+=lineCents(i.qty,i.price);a.qty+=Number(i.qty||0);a.cartons+=Number(i.cartons||0);a.net+=Number(i.net||0);a.gross+=Number(i.gross||0);return a;},{amount:0,qty:0,cartons:0,net:0,gross:0});result.amount=sum/100;return result;}
export function validateDocument(d){
 if(!TYPES[d.type]) throw Error('请选择正确的单据类型');
 if(!String(d.number||'').trim()) throw Error('请填写单据编号');
 if(d.type==='SL'){if(!/^\d{4}-\d{2}-\d{2}$/.test(d.date||''))throw Error('请选择面单日期');return validateShipping(d);}
 if(!d.buyer?.name?.trim()) throw Error('请填写或选择客户');
 if(!d.seller?.name?.trim()) throw Error('请填写或选择卖家公司');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(d.date||'')) throw Error('请选择单据日期');
 if(!['USD','EUR','CNY','GBP','JPY','HKD'].includes(d.currency)) throw Error('请选择币种');
 if(!Array.isArray(d.items)||!d.items.length||d.items.length>200) throw Error('请添加 1–200 个产品');
 for(const i of d.items){
  if(!i.name?.trim()) throw Error('请填写产品名称');
  if(!Number.isFinite(Number(i.qty))||Number(i.qty)<=0||Number(i.qty)>1e9) throw Error('产品数量必须大于 0 且不超过 10 亿');
  for(const k of ['price','cartons','net','gross']) if(!Number.isFinite(Number(i[k]||0))||Number(i[k]||0)<0||Number(i[k]||0)>1e9) throw Error('金额、箱数及重量须为有效非负数');
  if(Number(i.gross||0)<Number(i.net||0)) throw Error('毛重不能小于净重');
 }
 if(!Number.isSafeInteger(cents(totals(d.items).amount))) throw Error('金额超过可精确计算的范围');
 return d;
}
export function newNumber(type){return `${type}${new Date().toISOString().slice(0,10).replaceAll('-','')}-${crypto.randomUUID().slice(0,6).toUpperCase()}`;}
