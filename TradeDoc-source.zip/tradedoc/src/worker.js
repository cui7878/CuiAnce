import {api} from './api.js';
import html from './index.html';
import css from './style.css';
import app from '../dist/client/app.js';
const secure={'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'"};
export default{async fetch(request,env){const url=new URL(request.url);if(url.pathname.startsWith('/api/'))return api(request,env);if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});let body,type;
if(url.pathname==='/app.js'){body=app;type='application/javascript; charset=utf-8';}else if(url.pathname==='/style.css'){body=css;type='text/css; charset=utf-8';}else if(url.pathname==='/'||url.pathname==='/index.html'){body=html;type='text/html; charset=utf-8';}else return new Response('Not found',{status:404});return new Response(request.method==='HEAD'?null:body,{headers:{...secure,'Content-Type':type}});}};
