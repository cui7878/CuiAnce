import {validateDocument} from './domain.js';
const KINDS=new Set(['documents','products','sellers','customers','categories','notes']);
const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function api(request,env){
 const owner=request.headers.get('oai-authenticated-user-id');
 if(!owner) return json({error:'请登录后使用云端工作台',signin:'/signin-with-chatgpt?return_to=/'},401);
 if(!env.DB) return json({error:'云端数据库暂未就绪，请稍后重试'},503);
 const url=new URL(request.url);
 if(request.method!=='GET'&&request.headers.get('origin')&&request.headers.get('origin')!==url.origin) return json({error:'来源校验失败'},403);
 try{
  if(url.pathname==='/api/state'&&request.method==='GET'){
   const rows=await env.DB.prepare('SELECT kind, id, payload, version, updated_at FROM records WHERE owner = ? ORDER BY updated_at DESC').bind(owner).all();
   return json({user:{email:request.headers.get('oai-authenticated-user-email')||'',name:decodeName(request.headers)},records:rows.results.map(r=>({kind:r.kind,id:r.id,value:JSON.parse(r.payload),version:r.version,updatedAt:r.updated_at}))});
  }
  if(url.pathname==='/api/records'&&['POST','DELETE'].includes(request.method)){
   const raw=await request.text();
   if(raw.length>1800000)return json({error:'内容过大，请压缩图片或减少产品行'},413);
   const {kind,id,value,version=0}=JSON.parse(raw);
   if(!KINDS.has(kind)||typeof id!=='string'||!/^[a-zA-Z0-9_-]{1,80}$/.test(id)||!Number.isInteger(version)||version<0) return json({error:'无效的记录参数'},400);
   if(request.method==='DELETE'){
    const r=await env.DB.prepare('DELETE FROM records WHERE owner = ? AND kind = ? AND id = ? AND version = ?').bind(owner,kind,id,version).run();
    return r.meta.changes?json({ok:true}):json({error:'记录已被其他设备修改，请刷新后再操作'},409);
   }
   if(!value||typeof value!=='object'||Array.isArray(value))return json({error:'无效的记录内容'},400);
   if(kind==='documents')validateDocument(value);
   else if(kind==='notes'){if(typeof value.text!=='string'||value.text.length>20000)return json({error:'备注内容无效或过长'},400);}
   else if(typeof value.name!=='string'||!value.name.trim())return json({error:'请填写名称'},400);
   if(kind==='products'&&!['USD','EUR','CNY','GBP','JPY','HKD'].includes(value.currency||'USD'))return json({error:'请选择有效的产品币种'},400);
   if(kind==='products'&&(!Number.isFinite(Number(value.price))||Number(value.price)<0||!Number.isFinite(Number(value.stock))||Number(value.stock)<0))return json({error:'价格和库存须为有效非负数'},400);
   const now=new Date().toISOString();
   let r;
   if(version===0){
    r=await env.DB.prepare('INSERT INTO records (owner, kind, id, payload, version, updated_at) VALUES (?, ?, ?, ?, 1, ?) ON CONFLICT(owner, kind, id) DO NOTHING').bind(owner,kind,id,JSON.stringify(value),now).run();
   }else{
    r=await env.DB.prepare('UPDATE records SET payload = ?, version = version + 1, updated_at = ? WHERE owner = ? AND kind = ? AND id = ? AND version = ?').bind(JSON.stringify(value),now,owner,kind,id,version).run();
   }
   if(!r.meta.changes)return json({error:'此记录已在其他设备更新。请先复制当前内容，再刷新读取最新版本。'},409);
   return json({kind,id,value,version:version+1,updatedAt:now});
  }
  return json({error:'接口不存在'},404);
 }catch(error){if(error instanceof SyntaxError)return json({error:'请求格式错误'},400);if(error.message?.startsWith('D1_'))return json({error:'数据库暂时不可用，请稍后重试'},503);return json({error:error.message||'保存失败，请重试'},400);}
}
function decodeName(h){const n=h.get('oai-authenticated-user-full-name');if(!n)return '';try{return h.get('oai-authenticated-user-full-name-encoding')==='percent-encoded-utf-8'?decodeURIComponent(n):n;}catch{return n;}}
