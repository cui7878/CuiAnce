import {validateDocument} from './domain.js';
export const STORAGE_KEY='tradedoc-local-v1';
const kinds=new Set(['documents','products','sellers','customers','categories','notes']);
const clone=x=>JSON.parse(JSON.stringify(x));
function validate(kind,id,value){
 if(!kinds.has(kind)||typeof id!=='string'||!/^[a-zA-Z0-9_-]{1,80}$/.test(id)||!value||typeof value!=='object'||Array.isArray(value))throw Error('资料格式无效');
 if(kind==='documents')validateDocument(value);
 else if(kind==='notes'){if(typeof value.text!=='string'||value.text.length>20000)throw Error('备注格式无效');}
 else if(typeof value.name!=='string'||!value.name.trim())throw Error('请填写名称');
 if(kind==='products'){
  if(!['USD','EUR','CNY','GBP','JPY','HKD'].includes(value.currency||'USD'))throw Error('请选择有效币种');
  if(!Number.isFinite(Number(value.price))||Number(value.price)<0||!Number.isFinite(Number(value.stock))||Number(value.stock)<0)throw Error('价格和库存须为有效非负数');
 }
}
function validateRecords(records){
 if(!Array.isArray(records)||records.length>5000)throw Error('备份最多支持 5000 条记录');
 const keys=new Set();
 for(const r of records){validate(r.kind,r.id,r.value);if(!Number.isInteger(r.version)||r.version<1||typeof r.updatedAt!=='string')throw Error('记录版本格式无效');const key=r.kind+':'+r.id;if(keys.has(key))throw Error('备份包含重复记录');keys.add(key);}
 return records;
}
export function createLocalStore(getStorage){
 function read(){let raw;try{raw=getStorage().getItem(STORAGE_KEY);}catch{throw Error('无法读取本地资料，请允许浏览器存储并使用普通浏览模式。');}if(raw===null)return [];try{const data=JSON.parse(raw);if(data.schema!==1)throw Error();return validateRecords(data.records);}catch{throw Error('本地资料格式损坏，已保留原数据，请先备份浏览器资料再处理。');}}
 function write(records){validateRecords(records);try{getStorage().setItem(STORAGE_KEY,JSON.stringify({schema:1,records}));}catch{throw Error('本地保存失败，可能存储空间不足；当前内容仍在页面，请导出备份或缩小产品图片后重试。');}}
 return {
  async request(path,method='GET',body){
   const records=read();
   if(path==='/api/state'&&method==='GET')return {user:{name:'本地工作台'},records:clone(records)};
   if(path!=='/api/records'||!['POST','DELETE'].includes(method))throw Error('不支持的本地操作');
   const {kind,id,value,version=0}=body||{};
   if(!kinds.has(kind)||typeof id!=='string'||!Number.isInteger(version)||version<0)throw Error('无效记录');
   const index=records.findIndex(r=>r.kind===kind&&r.id===id),current=records[index];
   if(current?current.version!==version:version!==0)throw Error('资料已在另一个标签页修改，请重新读取后操作。');
   if(method==='DELETE'){if(index<0)throw Error('记录已被删除');records.splice(index,1);write(records);return {ok:true};}
   validate(kind,id,value);const r={kind,id,value:clone(value),version:version+1,updatedAt:new Date().toISOString()};
   if(index>=0)records.splice(index,1);records.unshift(r);write(records);return clone(r);
  },
  exportData(){return JSON.stringify({format:'TradeDoc Backup',schema:1,exportedAt:new Date().toISOString(),records:read()},null,2);},
  importData(text){
   if(typeof text!=='string'||text.length>30000000)throw Error('备份文件过大或格式无效');
   let data;try{data=JSON.parse(text);}catch{throw Error('备份不是有效的 JSON 文件');}
   if(data.format!=='TradeDoc Backup'||data.schema!==1)throw Error('请选择 TradeDoc 导出的备份文件');
   validateRecords(data.records);const current=read(),keys=new Set(current.map(r=>r.kind+':'+r.id));let imported=0,skipped=0;
   for(const r of data.records){const key=r.kind+':'+r.id;if(keys.has(key)){skipped++;continue;}current.push(clone(r));keys.add(key);imported++;}
   validateRecords(current);current.sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));write(current);return {imported,skipped};
  }
 };
}
