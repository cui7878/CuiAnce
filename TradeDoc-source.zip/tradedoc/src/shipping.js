import JsBarcode from 'jsbarcode';
export const LABEL_LIMITS={name:40,contact:30,phone:32,address:140,carrier:24,tracking:40,contents:50,notes:60,reference:40};
export function barcodeData(tracking){
 if(typeof tracking!=='string'||! /^[A-Za-z0-9-]{1,40}$/.test(tracking))throw Error('运单号须为 1–40 位英文字母、数字或短横线');
 const target={};JsBarcode(target,tracking,{format:'CODE128',displayValue:false});
 const bits=target.encodings.map(x=>x.data).join(''),quiet=10;
 // 92 mm usable width, minimum module width 0.254 mm (10 mil).
 if((bits.length+quiet*2)*.254>92)throw Error('运单号条码过密，无法适合 100 mm 标签，请核对运单号');
 return {bits,quiet};
}
function text(value,label,max,required=false){
 if(value===undefined||value===null)value='';
 if(typeof value!=='string'||(required&&!value.trim()))throw Error('请填写'+label);
 if(value.length>max)throw Error(label+'最多 '+max+' 个字符，请缩短后打印');
}
export function validateShipping(d){
 for(const [key,title]of [['seller','寄件'],['buyer','收件']]){
  const party=d[key]||{};
  for(const [field,label,required]of [['name','人 / 公司',true],['contact','联系人',false],['phone','电话',true],['address','地址',true]])text(party[field],title+label,LABEL_LIMITS[field],required);
 }
 const s=d.shipping||{};text(s.carrier,'快递公司',LABEL_LIMITS.carrier,true);barcodeData(s.tracking);
 if(!Number.isInteger(Number(s.parcels))||Number(s.parcels)<1||Number(s.parcels)>999)throw Error('包裹件数须为 1–999 的整数');
 if(!Number.isFinite(Number(s.weight))||Number(s.weight)<0||Number(s.weight)>99999)throw Error('重量须在 0–99999 kg 之间');
 text(s.contents,'内件品名',LABEL_LIMITS.contents);text(d.notes,'面单备注',LABEL_LIMITS.notes);text(d.reference,'关联订单',LABEL_LIMITS.reference);
 return d;
}
