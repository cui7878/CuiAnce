# TradeDoc Implementation Plan
> Execute inline, following superpowers:executing-plans. User has authorized making the website.
**Goal:** Deliver a responsive external trade document workspace with A4 printing and cloud records.
**Architecture:** Browser UI bundled into a Worker module; authenticated API with user-scoped D1 records and optimistic concurrency. No external AI or paid services.
**Tech Stack:** JavaScript modules, CSS, esbuild, Node test runner, SQLite integration.
**Spec:** docs/design.md
## Global Constraints
Phone/tablet/desktop/foldable responsiveness; four document types; printable A4; genuine cloud saving; private per-user records.
## Review Focus
Money precision; missing identity; cross-device overwrite; malicious user text; long printable tables.
## Task 1: Domain and storage
Files: src/domain.js, src/api.js, migrations/0001.sql, tests/domain.test.js, tests/api.test.js.
- [x] Test rounding, invalid values, unauthenticated API, user isolation, save/load/delete and stale versions.
- [x] Implement validation, totals, D1 API and schema; run node --test.
## Task 2: Responsive app
Files: src/app.js, src/style.css, src/index.html.
- [x] Implement four navigation pages, searchable records, CRUD editors, source-data snapshotting and image fields.
- [x] Preserve form drafts during navigation/resize, display storage status and errors; preview all four types.
## Task 3: Printing and delivery
Files: src/print.js, src/worker.js, scripts/build.mjs, tests/print.test.js.
- [x] Test escaping and type-specific print output.
- [x] Implement A4 print CSS with repeating table header and print action.
- [x] Build, review integration, publish private Site and verify deployment status.

## Verification limits
Browser QA tooling was unavailable; DOM interactions and real SQLite behavior were tested. Physical devices and actual printer pagination require manual acceptance. Hosted DB records table verified after deployment.
