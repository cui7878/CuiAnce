# Local-only conversion
User explicitly removed login and multi-device/cloud requirements.
- [x] Replace browser network persistence with versioned localStorage and validated records.
- [x] Keep all five document types, seller/customer/product/settings, A4 and 100x150 printing.
- [x] Add JSON export/import with additive merge, atomic writes, quota errors and record-limit protection.
- [x] Remove login, logout and cloud copy; self-contained classic-script HTML with embedded CSS and no font requests.
- [x] Regression tests: persistence, corrupted data, quota errors, backups, 5000-record boundary, no-fetch UI and bundled HTML startup.
- [x] Publish independent GitHub branch; preserve existing main. Pages enable API was denied by integration permissions and needs owner action.
Independent review found record-limit lockout; regression observed failing, then fixed by validating writes before commit. Physical browser/printer QA remains unverified.
