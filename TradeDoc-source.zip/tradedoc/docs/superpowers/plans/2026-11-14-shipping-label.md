# 100 × 150 mm shipping labels
Goal: Add printable, saved generic shipping labels to the existing site.
Scope: New SL document type with sender/recipient snapshots, carrier, existing tracking number, CODE128 barcode, parcels, weight and short contents. No automatic booking or invented official carrier routing codes. Existing A4 invoices remain A4.
Architecture: Reuse documents records, versioned cloud persistence, search/copy/editor. Separate shipping validation and barcode encoder; named CSS page for exact label size. User-selected browser printer settings remain necessary.
Files: src/shipping.js (validation/barcode), src/domain.js (SL type), src/print.js (label rendering), src/app.js (editor/preview/print), src/style.css (screen + named page), tests/*.test.js.
- [x] Regression tests: valid labels need no currency/product price; missing phone/address/tracking rejected; barcode has valid start/stop and quiet zones; label content escaped; cloud save and round-trip; label editor/print page switching.
- [x] Implement shipping domain and exact-size black/white label with readable fields and SVG bars. Limit field lengths and barcode module density; never truncate silently.
- [x] Add home creation, filters, reuse customer/seller data, editing/copy (clear tracking on copy), preview instructions and reprint. No financial/product fields in label editor.
- [x] Run tests/build; retain existing private Site identity, push exact source, package and deploy. Verify live bundle and layout limitations.
Verification limits: physical thermal printer alignment/scanning and real device/browser visual testing remain unverified in this environment.

Implementation assumption: no carrier was specified, so generic manual labels are implemented and explicitly identified. Official routing labels and automatic booking require a future carrier integration.
Independent code review reported no confirmed material defects. DOM and SQLite regressions cover label save/reprint, A4 switching, copy tracking reset and overflow blocking. Actual thermal-printer page size/scanning requires device acceptance.
